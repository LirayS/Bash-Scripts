# SSH Helper Tool
#
# The SSH Helper Tool is a Bash script designed to assist users in performing anonymous attacks using Tor, Kalitorify, and SSH. 
# This script automates the process of setting up an anonymous connection, establishing SSH connection to a target server, executing commands on the remote server, and saving the output to a log file.
# Ensure to run this script using sudo privileges.
#
# INSTALLATION
# git clone https://github.com/LirayS/ssh-helper-tool.git
# uznip SSH-helper-tool.zip
# cd SSH-helper-tool
# chmod +x SSH-helper-tool.sh
# sudo ./SSH-helper-tool.sh
#
# DISCLAIMER
# This tool is intended for educational and informational purposes only. 
# The author and contributors of this tool are not responsible for any misuse or illegal activities conducted using this tool.
